$(document).ready(function(){
	//Show and hide password
	$('.pass_show').append('<span class="ptxt">Show Password</span>');  
	
	//Show and hide password	
	$(document).on('click','.pass_show .ptxt', function(){ 
		$(this).text($(this).text() == "Show Password" ? "Hide Password" : "Show Password"); 
		$(this).prev().attr('type', function(index, attr){return attr == 'password' ? 'text' : 'password'; }); 
	});

	//basic form Validation
	$('#login').click(function(e){
		var email = $("#email").val();
		var password = $("#password").val();
		var submit = $("#login").val();
        $.ajax({
        	type: 'POST',
        	url: "helpers/auth.php",
        	data: {email:email,password:password,submit:submit},
        	cache: false,
        	success: function(result){
	          	console.log(result);
	          	result = result.trim();
	          	// alert(result);
	          	if (result == 'empty') {
		            $.alert({
		              theme: 'supervan', // 'material', 'bootstrap'
		              title: 'ERROR!',
		              content: 'Fill in All the Required Fields.',
		            });
	          	}else if (result == 'invalid_email') {
		            $.alert({
		              theme: 'supervan', // 'material', 'bootstrap'
		              title: 'ERROR!',
		              content: 'Invalid Email Format. Correct format: abc@example.com',
		            });
	          	}else if (result == 'invalid_credentials') {
		            $.alert({
		              theme: 'supervan', // 'material', 'bootstrap'
		              title: 'ERROR!',
		              content: 'Invalid Email or Password. Try Again',
		            });
	          	}else if (result == 'valid') {
		            $.dialog({
						theme: 'supervan', // 'material', 'bootstrap'
		            	title: 'Success!',
		            	content: 'Valid Email and Password. Redirecting',
						closeIcon: false,
					});
		            setTimeout("location.href = 'calculator.php';", 3000);

	          	}
        	}
        });
	});	
})
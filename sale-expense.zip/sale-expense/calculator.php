<?php 
include('includes/session-not-set.php');
include('includes/connection.php');
$user_id = $_SESSION['user_id'];

if (isset($_POST['reset'])) {
	$delete_q = mysqli_query($con, "DELETE FROM `transactions` WHERE `user_id`='$user_id'");
	if ($delete_q) {
		header('Location: calculator.php?msg=reset');
	}
}	
if (isset($_POST['submit'])) {
	$user_id = $_SESSION['user_id'];
	//1 for sale, 2 for expense
	$type = $_POST['type'];
	$amount = $_POST['amount'];
	$description = $_POST['description'];

	//for Sale
	if ($type == 1) {
		$sale_q = "INSERT INTO `transactions` (`type`, `sale`, `expense`, `description`,`total`,`user_id`) VALUES ('$type', '$amount','0','$description','$amount','$user_id')";
		$sale_qr = mysqli_query($con, $sale_q);
		if ($sale_qr) {
			header('Location: calculator.php?msg=sale_added');
		}
	}else if($type == 2){ //for Expense
		$expense_q = "INSERT INTO `transactions` (`type`, `sale`, `expense`, `description`,`total`,`user_id`) VALUES ('$type', '0','$amount','$description','$amount','$user_id')";
		$expense_qr = mysqli_query($con, $expense_q);
		if ($expense_qr) {
			header('Location: calculator.php?msg=expense_added');
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sale Expense Calculator</title>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
  		<!-- Navbar -->
  		<nav class="navbar navbar-default">
			<div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			    	<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			    	    <span class="sr-only">Toggle navigation</span>
			        	<span class="icon-bar"></span>
			        	<span class="icon-bar"></span>
			        	<span class="icon-bar"></span>
			      	</button>
			      <a class="navbar-brand" href="#">Welcome: <?php echo $_SESSION['email']; ?>!</a>
		    	</div>

		    	<!-- Collect the nav links, forms, and other content for toggling -->
		    	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      		<ul class="nav navbar-nav">
		      		</ul>
		      		<ul class="nav navbar-nav navbar-right">
		        		<li><a href="includes/logout.php">Logout</a></li>
		      		</ul>
		    	</div><!-- /.navbar-collapse -->
		  	</div><!-- /.container-fluid -->
		</nav>
		<?php
  		if (isset($_GET['msg'])) {
  			if ($_GET['msg'] == 'already_logged_in') {
  				?><div class="alert alert-danger"><p class="text-center">You are already Logged In.</p></div><?php
  			}else if ($_GET['msg'] == 'sale_added') {
  				?><div class="alert alert-success"><p class="text-center">Sale Added in the Sheet</p></div><?php
  			}else if ($_GET['msg'] == 'expense_added') {
  				?><div class="alert alert-success"><p class="text-center">Expense Added in the Sheet</p></div><?php
  			}else if ($_GET['msg'] == 'reset') {
  				?><div class="alert alert-success"><p class="text-center">Balance Sheet Cleared Successfully</p></div><?php
  			}
  		}
  		?>
		<div class="jumbotron">
			<h2>Sale Expense Calculator</h2>
			<form method="post">
				<div class="row">	
					<div class="col-sm-4">
						<div class="form-group">
							<label for="type">Transaction type</label>
							<select name="type" class="form-control">
								<option>Select Transaction type</option>
								<option value="1">Sale</option>
								<option value="2">Expense</option>
							</select>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group">
							<label for="amount">Transaction amount</label>
							<input type="number" name="amount" class="form-control" placeholder="Amount of Transaction">
						</div>
					</div>
					<div class="col-sm-4">
						<div class="form-group">
							<label for="description">Description</label>
							<input type="text" class="form-control" rows="3" cols="5" name="description" placeholder="Description of transaction">
						</div>
					</div>
				</div>
				<div class="row pull-right">
					<div class="col-sm-4">
						<div class="form-group">
							<input type="submit" name="submit" value="Calculate" class="btn btn-primary">
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
	<hr>
	<div class="container">
		<div class="row">
			<h1 class="text-center">Balance Sheet Details</h1>
		</div>
		<div class="row pull-right">
			<form method="post">
				<div class="form-group">
					<button type="submit" name="reset" value="Clear Balance Sheet" class="btn btn-danger">Clear Balance Sheet</button>	
				</div>
			</form>
		</div>	
		<table class="table table-bordered">
		    <thead>
		      	<tr>
		        	<th>Sr#</th>
		        	<th>Description</th>
		        	<th>Sale</th>
		        	<th>Expense</th>
		      	</tr>
		    </thead>    
		    <tbody>
		      	<?php
				$fetch_record = "SELECT * FROM `transactions` JOIN `users` ON `transactions`.`user_id`=`users`.`user_id` WHERE `users`.`user_id`='$user_id'";
				$fetch_record_r = mysqli_query($con, $fetch_record);
				$record_found = mysqli_num_rows($fetch_record_r);
				if ($record_found > 0) {
					$sr = 1;
					$net_total = 0;
					while($records = mysqli_fetch_assoc($fetch_record_r)){
						if ($records['type'] == 1) {
							$net_total = $net_total + $records['sale'];
						}
						if($records['type'] == 2){
							$net_total = $net_total - $records['expense'];
						}
				?>
				      	<tr>
				        	<td><?php echo $sr++; ?></td>
				        	<td style="text-transform: capitalize;"><?php echo $records['description']; ?></td>
				        	<td><?php echo $records['sale'];?></td>
				        	<td><?php echo $records['expense'];?></td>
				      	</tr>
				      	<?php
				      	if (($sr % 2)) { // skip even members
					        ?>
					        <tr>
					      		<td colspan="2"></td>
					      		<td colspan="2" class="label-info text-center" style="color: #fff;">Total Balance: <?php echo $net_total; ?></td>
					      	</tr>
					        <?php
					    }
				      	?>
		      	<?php
		      		}
		      			?>
		      			<tr>
				      		<td colspan="4" class="label-info text-center" style="color: #fff;">Total: <?php echo $net_total; ?></td>
				      	</tr>
		      			<?php
				}else{
					echo "<h1 class='text-center text-danger'>No Record Found</h1>";
				}
				?>
		    </tbody>
		</table>
	</div>
</body>
</html>
<?php
$con = mysqli_connect('localhost', 'root', '', 'calc');

if (!$con) {
	die("Failed To Connect to DB");
}
?>
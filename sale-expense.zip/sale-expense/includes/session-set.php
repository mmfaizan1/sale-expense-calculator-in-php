<?php 
session_start();

if (isset($_SESSION['email'])) {
	header('Location: profile.php?msg=already_logged_in');
}
?>